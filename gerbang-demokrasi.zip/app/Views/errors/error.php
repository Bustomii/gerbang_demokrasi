<<!DOCTYPE html>
<html>
<head>
  <title>Error Page</title>
</head>
<body>
  <h2>Anda Dilarang Mengakses Halaman Ini</h2>
  <p>Anda akan diarahkan ke halaman depan.</p>
  <hr/>
</body>
</html> 